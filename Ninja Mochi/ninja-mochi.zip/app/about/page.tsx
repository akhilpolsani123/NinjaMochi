"use client"

import { motion } from "framer-motion"
import { Parallax } from "@/components/parallax"
import { Card, CardContent } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"

export default function AboutPage() {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative h-[50vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-black/5 backdrop-blur-sm z-0"></div>
        <motion.div
          className="relative z-10 text-center px-4"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <h1 className="text-5xl md:text-6xl font-bold tracking-tighter mb-4">Our Story</h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            The secret history of Ninja Mochi and our mission to create the perfect donut
          </p>
        </motion.div>
      </section>

      {/* Story Section */}
      <section className="py-20 px-4">
        <div className="max-w-4xl mx-auto">
          <Parallax>
            <Card className="bg-background/50 backdrop-blur-sm border mb-12">
              <CardContent className="p-8">
                <h2 className="text-3xl font-bold mb-6">The Beginning</h2>
                <p className="text-muted-foreground mb-4">
                  Ninja Mochi was born from a secret recipe, passed down through generations of culinary masters in the
                  mountains of Japan. Our founder, Master Takeshi, spent years perfecting the art of mochi making before
                  bringing his creations to the world.
                </p>
                <p className="text-muted-foreground">
                  Like the ninjas of ancient Japan, our donuts move silently but leave a lasting impression. Each bite
                  is a perfect balance of soft, chewy texture and bold, unexpected flavors.
                </p>
              </CardContent>
            </Card>
          </Parallax>

          <Separator className="my-12" />

          <Parallax>
            <Card className="bg-background/50 backdrop-blur-sm border mb-12">
              <CardContent className="p-8">
                <h2 className="text-3xl font-bold mb-6">Our Philosophy</h2>
                <p className="text-muted-foreground mb-4">
                  At Ninja Mochi, we believe in the perfect harmony of tradition and innovation. Our donuts honor the
                  ancient art of mochi making while embracing modern culinary techniques and flavors.
                </p>
                <p className="text-muted-foreground">
                  We source only the finest ingredients, working with local farmers and suppliers to ensure every donut
                  meets our exacting standards. Like a ninja's precision, we pay attention to every detail.
                </p>
              </CardContent>
            </Card>
          </Parallax>

          <Separator className="my-12" />

          <Parallax>
            <Card className="bg-background/50 backdrop-blur-sm border">
              <CardContent className="p-8">
                <h2 className="text-3xl font-bold mb-6">Our Promise</h2>
                <p className="text-muted-foreground mb-4">
                  Each Ninja Mochi donut is crafted with care, precision, and a touch of mystery. We promise an
                  experience that delights the senses and leaves you craving more.
                </p>
                <p className="text-muted-foreground">
                  Whether you're a mochi master or trying our donuts for the first time, we welcome you to the secret
                  world of Ninja Mochi. Deliciously soft. Dangerously addictive.
                </p>
              </CardContent>
            </Card>
          </Parallax>
        </div>
      </section>
    </div>
  )
}
