"use client"

import Image from "next/image"
import Link from "next/link"
import { ChevronRight, Clock, MapPin, Phone } from "lucide-react"

import { ScanLines } from "@/components/scan-lines"
import { GlitchText } from "@/components/glitch-text"
import { NeonButton } from "@/components/neon-button"
import { CyberpunkTitle } from "@/components/cyberpunk-title"
import { AnimatedFoodGallery } from "@/components/animated-food-gallery"
import { AnimatedDonutGallery } from "@/components/animated-donut-gallery"
import { AnimatedBobaGallery } from "@/components/animated-boba-gallery"
import { AnimatedCorndogGallery } from "@/components/animated-corndog-gallery"
import { Card, CardContent } from "@/components/ui/card"

export default function Home() {
  return (
    <div className="dark flex min-h-screen flex-col bg-black text-slate-50">
      <ScanLines />

      {/* Navigation */}
      <header className="sticky top-0 z-50 border-b border-slate-900/30 bg-black/80 backdrop-blur-md">
        <div className="container flex h-16 items-center justify-between">
          <Link href="/" className="flex items-center gap-2 font-bold">
            <Image
              src="/images/ninja-logo.png"
              alt="Ninja Mochi Donut"
              width={40}
              height={40}
              className="rounded-full"
            />
            <span className="text-xl text-[#00e5d3]">NINJA</span>
            <span className="text-xl text-black dark:text-white">MOCHI</span>
          </Link>
          <nav className="hidden md:flex">
            <ul className="flex items-center gap-6">
              <li>
                <Link
                  href="#"
                  className="text-sm font-medium tracking-wide text-[#00e5d3] transition-colors hover:text-[#00e5d3]/80"
                >
                  _HOME
                </Link>
              </li>
              <li>
                <Link
                  href="#about"
                  className="text-sm font-medium tracking-wide text-[#00e5d3] transition-colors hover:text-[#00e5d3]/80"
                >
                  _ABOUT
                </Link>
              </li>
              <li>
                <Link
                  href="/menu"
                  className="text-sm font-medium tracking-wide text-[#00e5d3] transition-colors hover:text-[#00e5d3]/80"
                >
                  _MENU
                </Link>
              </li>
              <li>
                <Link
                  href="/locations"
                  className="text-sm font-medium tracking-wide text-[#00e5d3] transition-colors hover:text-[#00e5d3]/80"
                >
                  _LOCATIONS
                </Link>
              </li>
            </ul>
          </nav>
          <NeonButton color="teal">ORDER_NOW</NeonButton>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative flex min-h-[85vh] flex-col items-center justify-center overflow-hidden bg-black text-white">
        <div className="absolute inset-0 z-0">
          <AnimatedFoodGallery />
        </div>
        <div className="container relative z-10 flex flex-col items-center justify-center gap-6 px-4 text-center sm:px-6">
          <div className="relative mb-4 flex flex-col items-center">
            <div className="absolute -top-12 left-0 right-0 text-xs font-mono text-[#00e5d3] opacity-70">
              {`// DESSERT BAR SYSTEM ONLINE //`}
            </div>
            <CyberpunkTitle />
            <div className="mt-2 text-xs font-mono text-[#00e5d3] opacity-70">{`/* MOCHI DONUTS • BOBA • KOREAN CORNDOGS */`}</div>
          </div>
          <p className="max-w-2xl text-lg font-mono text-[#00e5d3]/80">
            <GlitchText>ASIAN FUSION DESSERTS WITH A DIGITAL TWIST</GlitchText>
          </p>
          <div className="mt-6 flex flex-wrap gap-6">
            <Link href="/menu">
              <NeonButton color="teal" size="lg">
                {"<VIEW_MENU />"}
              </NeonButton>
            </Link>
            <NeonButton color="teal" size="lg" variant="outline">
              {"<ORDER_ONLINE />"}
            </NeonButton>
          </div>
        </div>
        <div className="pointer-events-none absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-black to-transparent"></div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20">
        <div className="container">
          <div className="mx-auto max-w-3xl text-center">
            <div className="inline-block border-b-2 border-[#00e5d3] pb-2">
              <h2 className="text-3xl font-bold tracking-wide text-[#00e5d3] sm:text-4xl">OUR_STORY.exe</h2>
            </div>
            <p className="mb-8 mt-6 font-mono text-[#00e5d3]/70">
              {`>> NINJA MOCHI DONUT COMBINES TRADITIONAL ASIAN DESSERTS WITH MODERN FUSION FLAVORS. 
              OUR MENU FEATURES HANDCRAFTED MOCHI DONUTS, KOREAN CORNDOGS, BINGSU, BOBA DRINKS, 
              AND MORE - ALL MADE WITH PREMIUM INGREDIENTS AND AUTHENTIC RECIPES.`}
            </p>
            <div className="grid gap-8 md:grid-cols-2">
              <Card className="border border-slate-900/50 bg-black/60 backdrop-blur-sm">
                <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-[#00e5d3] to-transparent"></div>
                <CardContent className="flex flex-col items-center gap-2 p-6">
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-[#00e5d3]/20 text-[#00e5d3]">
                    <MapPin className="h-6 w-6" />
                  </div>
                  <h3 className="text-xl font-medium text-[#00e5d3]">LOCATION_1.sys</h3>
                  <p className="text-center font-mono text-sm text-[#00e5d3]/70">
                    6181 Saratoga Blvd Ste: 107A
                    <br />
                    Corpus Christi, TX 78414
                    <br />
                    (361) 442-2160
                  </p>
                  <div className="mt-2 text-center font-mono text-xs text-[#00e5d3]/70">
                    MON-THU: 11AM-9PM
                    <br />
                    FRI-SAT: 11AM-9:30PM
                    <br />
                    SUN: 11AM-9PM
                  </div>
                </CardContent>
              </Card>
              <Card className="border border-slate-900/50 bg-black/60 backdrop-blur-sm">
                <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-[#00e5d3] to-transparent"></div>
                <CardContent className="flex flex-col items-center gap-2 p-6">
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-[#00e5d3]/20 text-[#00e5d3]">
                    <MapPin className="h-6 w-6" />
                  </div>
                  <h3 className="text-xl font-medium text-[#00e5d3]">LOCATION_2.sys</h3>
                  <p className="text-center font-mono text-sm text-[#00e5d3]/70">
                    5425 S Padre Island Dr Suite 113
                    <br />
                    Corpus Christi, TX 78411
                    <br />
                    (361) 299-0458
                  </p>
                  <div className="mt-2 text-center font-mono text-xs text-[#00e5d3]/70">
                    MON-THU: 11AM-9PM
                    <br />
                    FRI-SAT: 11AM-9:30PM
                    <br />
                    SUN: 11AM-9PM
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Animated Donut Gallery */}
      <AnimatedDonutGallery />

      {/* Animated Boba Gallery */}
      <AnimatedBobaGallery />

      {/* Animated Corndog Gallery */}
      <AnimatedCorndogGallery />

      {/* Menu Preview Section */}
      <section id="menu" className="py-20">
        <div className="container">
          <div className="mx-auto max-w-3xl text-center">
            <div className="inline-block border-b-2 border-[#00e5d3] pb-2">
              <h2 className="text-3xl font-bold tracking-wide text-[#00e5d3] sm:text-4xl">MENU_DATA</h2>
            </div>
            <p className="mb-12 mt-6 font-mono text-[#00e5d3]/70">
              {`>> BROWSE OUR DATABASE OF ASIAN FUSION DESSERTS AND SNACKS, FEATURING AUTHENTIC 
              FLAVORS WITH A MODERN DIGITAL TWIST.`}
            </p>
          </div>

          <div className="mt-12 text-center">
            <Link href="/menu">
              <NeonButton color="teal" size="lg">
                ACCESS FULL MENU <ChevronRight className="ml-2 h-4 w-4" />
              </NeonButton>
            </Link>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20">
        <div className="container">
          <div className="mx-auto max-w-3xl text-center">
            <div className="inline-block border-b-2 border-[#00e5d3] pb-2">
              <h2 className="text-3xl font-bold tracking-wide text-[#00e5d3] sm:text-4xl">CONNECT.sys</h2>
            </div>
            <p className="mb-12 mt-6 font-mono text-[#00e5d3]/70">
              {`>> INITIATE COMMUNICATION PROTOCOL OR VISIT OUR LOCATIONS. OUR NINJA TEAM IS 
              READY TO SERVE YOU.`}
            </p>
          </div>
          <div className="mx-auto max-w-4xl">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <Card className="border border-slate-900/50 bg-black/60 backdrop-blur-sm">
                <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-[#00e5d3] to-transparent"></div>
                <CardContent className="p-6">
                  <h3 className="mb-4 text-xl font-bold text-[#00e5d3]">{">//SARATOGA_LOCATION"}</h3>
                  <div className="space-y-6">
                    <div className="flex items-start gap-3">
                      <MapPin className="mt-1 h-5 w-5 text-[#00e5d3]" />
                      <div>
                        <p className="font-mono font-medium text-[#00e5d3]">GEO_LOCATION</p>
                        <p className="font-mono text-sm text-[#00e5d3]/70">
                          6181 Saratoga Blvd Ste: 107A
                          <br />
                          Corpus Christi, TX 78414
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <Phone className="mt-1 h-5 w-5 text-[#00e5d3]" />
                      <div>
                        <p className="font-mono font-medium text-[#00e5d3]">COMM_LINK</p>
                        <p className="font-mono text-sm text-[#00e5d3]/70">(361) 442-2160</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <Clock className="mt-1 h-5 w-5 text-[#00e5d3]" />
                      <div>
                        <p className="font-mono font-medium text-[#00e5d3]">OPERATION_CYCLE</p>
                        <p className="font-mono text-sm text-[#00e5d3]/70">
                          MONDAY - THURSDAY: 11AM-9PM
                          <br />
                          FRIDAY - SATURDAY: 11AM-9:30PM
                          <br />
                          SUNDAY: 11AM-9PM
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border border-slate-900/50 bg-black/60 backdrop-blur-sm">
                <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-[#00e5d3] to-transparent"></div>
                <CardContent className="p-6">
                  <h3 className="mb-4 text-xl font-bold text-[#00e5d3]">{">//PADRE_ISLAND_LOCATION"}</h3>
                  <div className="space-y-6">
                    <div className="flex items-start gap-3">
                      <MapPin className="mt-1 h-5 w-5 text-[#00e5d3]" />
                      <div>
                        <p className="font-mono font-medium text-[#00e5d3]">GEO_LOCATION</p>
                        <p className="font-mono text-sm text-[#00e5d3]/70">
                          5425 S Padre Island Dr Suite 113
                          <br />
                          Corpus Christi, TX 78411
                          <br />
                          Moore Plaza
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <Phone className="mt-1 h-5 w-5 text-[#00e5d3]" />
                      <div>
                        <p className="font-mono font-medium text-[#00e5d3]">COMM_LINK</p>
                        <p className="font-mono text-sm text-[#00e5d3]/70">(361) 299-0458</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <Clock className="mt-1 h-5 w-5 text-[#00e5d3]" />
                      <div>
                        <p className="font-mono font-medium text-[#00e5d3]">OPERATION_CYCLE</p>
                        <p className="font-mono text-sm text-[#00e5d3]/70">
                          MONDAY - THURSDAY: 11AM-9PM
                          <br />
                          FRIDAY - SATURDAY: 11AM-9:30PM
                          <br />
                          SUNDAY: 11AM-9PM
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="mt-8">
              <Card className="border border-slate-900/50 bg-black/60 backdrop-blur-sm">
                <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-[#00e5d3] to-transparent"></div>
                <CardContent className="p-6">
                  <h3 className="mb-4 text-xl font-bold text-[#00e5d3]">{">//ONLINE_PRESENCE"}</h3>
                  <div className="flex items-start gap-3">
                    <div className="mt-1 h-5 w-5 text-[#00e5d3] flex items-center justify-center">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="20"
                        height="20"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      >
                        <circle cx="12" cy="12" r="10"></circle>
                        <line x1="2" y1="12" x2="22" y2="12"></line>
                        <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path>
                      </svg>
                    </div>
                    <div>
                      <p className="font-mono font-medium text-[#00e5d3]">WEBSITE</p>
                      <p className="font-mono text-sm text-[#00e5d3]/70">
                        <a
                          href="https://ninjamochidonut.com"
                          target="_blank"
                          rel="noopener noreferrer"
                          className="hover:text-[#00e5d3]"
                        >
                          ninjamochidonut.com
                        </a>
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-900/30 py-12">
        <div className="container">
          <div className="grid gap-8 md:grid-cols-3">
            <div>
              <h3 className="mb-4 flex items-center gap-2 text-xl font-bold">
                <Image
                  src="/images/ninja-logo.png"
                  alt="Ninja Mochi Donut"
                  width={30}
                  height={30}
                  className="rounded-full"
                />
                <span className="text-[#00e5d3]">NINJA</span>
                <span className="text-black dark:text-white">MOCHI</span>
              </h3>
              <p className="font-mono text-sm text-[#00e5d3]/70">
                {"// ASIAN FUSION DESSERT BAR. MOCHI DONUTS, BOBA, KOREAN CORNDOGS, AND MORE."}
              </p>
              <p className="font-mono text-sm text-[#00e5d3]/70 mt-2">{"// TWO LOCATIONS IN CORPUS CHRISTI, TX"}</p>
              <p className="font-mono text-sm text-[#00e5d3]/70 mt-2">
                <a
                  href="https://ninjamochidonut.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-[#00e5d3]"
                >
                  ninjamochidonut.com
                </a>
              </p>
            </div>
            <div>
              <h3 className="mb-4 text-lg font-medium text-[#00e5d3]">{">/LINKS"}</h3>
              <ul className="space-y-2 font-mono text-sm">
                <li>
                  <Link href="#" className="text-[#00e5d3]/80 transition-colors hover:text-[#00e5d3]">
                    _HOME
                  </Link>
                </li>
                <li>
                  <Link href="#about" className="text-[#00e5d3]/80 transition-colors hover:text-[#00e5d3]">
                    _ABOUT
                  </Link>
                </li>
                <li>
                  <Link href="/menu" className="text-[#00e5d3]/80 transition-colors hover:text-[#00e5d3]">
                    _MENU
                  </Link>
                </li>
                <li>
                  <Link href="/locations" className="text-[#00e5d3]/80 transition-colors hover:text-[#00e5d3]">
                    _LOCATIONS
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="mb-4 text-lg font-medium text-[#00e5d3]">{">/FOLLOW_US"}</h3>
              <p className="mb-4 font-mono text-sm text-[#00e5d3]/70">
                {"// JOIN OUR NETWORK FOR UPDATES AND EXCLUSIVE DEALS."}
              </p>
              <div className="flex gap-4">
                <NeonButton color="teal">INSTAGRAM</NeonButton>
                <NeonButton color="teal">FACEBOOK</NeonButton>
              </div>
            </div>
          </div>
          <div className="mt-8 border-t border-slate-900/30 pt-8 text-center font-mono text-xs text-[#00e5d3]/50">
            <p>© {new Date().getFullYear()} NINJA MOCHI DONUT // ALL RIGHTS RESERVED</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
