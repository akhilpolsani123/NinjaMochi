"use client"

import { motion } from "framer-motion"
import Image from "next/image"
import Link from "next/link"
import { ScanLines } from "@/components/scan-lines"
import { GlitchText } from "@/components/glitch-text"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { AnimatedDonut } from "@/components/animated-donut"
import { AnimatedBoba } from "@/components/animated-boba"
import { AnimatedCorndog } from "@/components/animated-corndog"
import { Card, CardContent } from "@/components/ui/card"

export default function MenuPage() {
  return (
    <div className="dark min-h-screen bg-black text-slate-50">
      <ScanLines />

      {/* Navigation */}
      <header className="sticky top-0 z-50 border-b border-slate-900/30 bg-black/80 backdrop-blur-md">
        <div className="container flex h-16 items-center justify-between">
          <Link href="/" className="flex items-center gap-2 font-bold">
            <Image
              src="/images/ninja-logo.png"
              alt="Ninja Mochi Donut"
              width={40}
              height={40}
              className="rounded-full"
            />
            <span className="text-xl text-[#00e5d3]">NINJA</span>
            <span className="text-xl text-black dark:text-white">MOCHI</span>
          </Link>
          <nav className="hidden md:flex">
            <ul className="flex items-center gap-6">
              <li>
                <Link
                  href="/"
                  className="text-sm font-medium tracking-wide text-[#00e5d3] transition-colors hover:text-[#00e5d3]/80"
                >
                  _HOME
                </Link>
              </li>
              <li>
                <Link
                  href="/#about"
                  className="text-sm font-medium tracking-wide text-[#00e5d3] transition-colors hover:text-[#00e5d3]/80"
                >
                  _ABOUT
                </Link>
              </li>
              <li>
                <Link
                  href="/menu"
                  className="text-sm font-medium tracking-wide text-[#00e5d3] transition-colors hover:text-[#00e5d3]/80"
                >
                  _MENU
                </Link>
              </li>
              <li>
                <Link
                  href="/locations"
                  className="text-sm font-medium tracking-wide text-[#00e5d3] transition-colors hover:text-[#00e5d3]/80"
                >
                  _LOCATIONS
                </Link>
              </li>
            </ul>
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative h-[40vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-black/50 backdrop-blur-sm z-0"></div>
        <motion.div
          className="relative z-10 text-center px-4"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <h1 className="text-5xl md:text-6xl font-bold tracking-tighter mb-4">
            <GlitchText>FULL_MENU.exe</GlitchText>
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto font-mono text-[#00e5d3]/70">
            {`>> BROWSE OUR COMPLETE DATABASE OF ASIAN FUSION DESSERTS AND SNACKS`}
          </p>
        </motion.div>
      </section>

      {/* Menu Section */}
      <section className="py-12 px-4">
        <div className="container mx-auto">
          <Tabs defaultValue="mochi" className="w-full">
            <TabsList className="grid w-full grid-cols-5 mb-8">
              <TabsTrigger value="mochi">Mochi Donuts</TabsTrigger>
              <TabsTrigger value="boba">Boba Refreshers</TabsTrigger>
              <TabsTrigger value="corndogs">Korean Corndogs</TabsTrigger>
              <TabsTrigger value="bingsu">Bingsu</TabsTrigger>
              <TabsTrigger value="drinks">Drinks</TabsTrigger>
            </TabsList>

            {/* Mochi Donuts Tab */}
            <TabsContent value="mochi" className="mt-0">
              <div className="bg-black/60 backdrop-blur-sm border border-slate-900/50 p-6 rounded-md mb-8">
                <h2 className="text-2xl font-bold text-[#00e5d3] mb-4">MOCHI_DONUTS.sys</h2>

                {/* Actual Menu Image */}
                <div className="mb-8 flex justify-center">
                  <Card className="overflow-hidden border-slate-900/50 bg-black/60 backdrop-blur-sm w-full max-w-3xl">
                    <CardContent className="p-0">
                      <Image
                        src="/images/menu-donuts.png"
                        alt="Mochi Donuts Menu"
                        width={800}
                        height={600}
                        className="w-full h-auto"
                      />
                    </CardContent>
                  </Card>
                </div>

                {/* Animated Donut Showcase */}
                <div className="flex flex-wrap justify-center gap-8 mb-8">
                  <AnimatedDonut
                    name="CHURRO"
                    color="#E6C19C"
                    toppingColor="#C19A6B"
                    sprinkleColors={["#FFFFFF", "#E6C19C", "#C19A6B"]}
                    size={120}
                  />
                  <AnimatedDonut
                    name="STRAWBERRY"
                    color="#FFCDD2"
                    toppingColor="#E57373"
                    sprinkleColors={["#FFFFFF", "#FFEBEE", "#FFCDD2"]}
                    size={120}
                  />
                  <AnimatedDonut
                    name="MATCHA"
                    color="#C8E6C9"
                    toppingColor="#388E3C"
                    sprinkleColors={["#FFFFFF", "#F5F5F5", "#E0E0E0"]}
                    size={120}
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h3 className="text-xl font-bold text-white mb-4">FLAVORS</h3>
                    <ul className="space-y-2 font-mono grid grid-cols-2 gap-x-4">
                      <li>CHURRO</li>
                      <li>GLAZE</li>
                      <li>CHOCOLATE</li>
                      <li>STRAWBERRY</li>
                      <li>OREO</li>
                      <li>MATCHA</li>
                      <li>TARO</li>
                      <li>FRUITY PEBBLES</li>
                      <li>PEACH MANGO</li>
                      <li>FRUIT PUNCH</li>
                      <li>COTTON CANDY</li>
                      <li>BEIGNET</li>
                    </ul>
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-white mb-4">SPECIALS</h3>
                    <ul className="space-y-4 font-mono">
                      <li className="flex justify-between">
                        <span>MOCHI MONSTER</span>
                        <span className="text-[#00e5d3]">$5.65</span>
                      </li>
                      <li className="text-sm text-muted-foreground">
                        (1 DONUT OF CHOICE + 1 ICECREAM SCOOP OF CHOICE)
                      </li>
                    </ul>
                  </div>
                </div>
              </div>

              <div className="bg-black/60 backdrop-blur-sm border border-slate-900/50 p-6 rounded-md">
                <h3 className="text-xl font-bold text-white mb-4">ICECREAM_SCOOPS.sys</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <ul className="space-y-4 font-mono">
                      <li className="flex justify-between">
                        <span>1 SCOOP CUP</span>
                        <span className="text-[#00e5d3]">$4.50</span>
                      </li>
                      <li className="flex justify-between">
                        <span>2 SCOOP CUP</span>
                        <span className="text-[#00e5d3]">$5.95</span>
                      </li>
                      <li className="flex justify-between">
                        <span>1 SCOOP WAFFLE CONE</span>
                        <span className="text-[#00e5d3]">$5.95</span>
                      </li>
                      <li className="flex justify-between">
                        <span>2 SCOOP WAFFLE CONE</span>
                        <span className="text-[#00e5d3]">$6.95</span>
                      </li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-bold mb-2">EXTRA TOPPINGS ($0.50)</h4>
                    <p className="text-sm text-muted-foreground font-mono">
                      BANANA, STRAWBERRY, SPRINKLES, MOCHI, OREO CRUMBS, DRIZZLES (CHOCOLATE, WHITE CHOCOLATE, CARAMEL)
                    </p>
                  </div>
                </div>
              </div>
            </TabsContent>

            {/* Boba Refreshers Tab */}
            <TabsContent value="boba" className="mt-0">
              <div className="bg-black/60 backdrop-blur-sm border border-slate-900/50 p-6 rounded-md">
                <h2 className="text-2xl font-bold text-[#00e5d3] mb-4">BOBA_REFRESHERS.sys</h2>

                {/* Actual Menu Image */}
                <div className="mb-8 flex justify-center">
                  <Card className="overflow-hidden border-slate-900/50 bg-black/60 backdrop-blur-sm w-full max-w-3xl">
                    <CardContent className="p-0">
                      <Image
                        src="/images/menu-boba.png"
                        alt="Boba Refreshers Menu"
                        width={800}
                        height={600}
                        className="w-full h-auto"
                      />
                    </CardContent>
                  </Card>
                </div>

                {/* Animated Boba Showcase */}
                <div className="flex flex-wrap justify-center gap-8 mb-8">
                  <AnimatedBoba name="RYUJIN" color="#F48FB1" bubbleColor="#F06292" size={120} />
                  <AnimatedBoba name="STIGMA" color="#FFF9C4" bubbleColor="#FBC02D" size={120} />
                  <AnimatedBoba name="SEA BREEZE" color="#81D4FA" bubbleColor="#FBC02D" size={120} />
                </div>

                <p className="mb-4 text-white font-mono">ALL REFRESHERS $6.49 (COMES WITH BOBA)</p>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  <div className="space-y-2">
                    <h3 className="font-bold text-white">RYUJIN</h3>
                    <p className="text-sm text-muted-foreground font-mono">STRAWBERRY LIME SODA, STRAWBERRY POPPERS</p>
                  </div>
                  <div className="space-y-2">
                    <h3 className="font-bold text-white">WATERMELON RIND</h3>
                    <p className="text-sm text-muted-foreground font-mono">
                      WATERMELON SYRUP, LIME SODA, STRAWBERRY POPPERS
                    </p>
                  </div>
                  <div className="space-y-2">
                    <h3 className="font-bold text-white">STIGMA</h3>
                    <p className="text-sm text-muted-foreground font-mono">SWEET VANILLA MILK, HONEY BOBA</p>
                  </div>
                  <div className="space-y-2">
                    <h3 className="font-bold text-white">ILLUSION</h3>
                    <p className="text-sm text-muted-foreground font-mono">DRAGONFRUIT, LYCHEE, STRAWBERRY POPPERS</p>
                  </div>
                  <div className="space-y-2">
                    <h3 className="font-bold text-white">SEA BREEZE</h3>
                    <p className="text-sm text-muted-foreground font-mono">
                      HONEYDEW, BLUE CURAÇAO, LIME SODA, HONEY BOBA
                    </p>
                  </div>
                  <div className="space-y-2">
                    <h3 className="font-bold text-white">DITTO</h3>
                    <p className="text-sm text-muted-foreground font-mono">
                      STRAWBERRY MILK, HONEY BOBA, WHIP CREAM, SPRINKLE
                    </p>
                  </div>
                </div>
              </div>
            </TabsContent>

            {/* Korean Corndogs Tab */}
            <TabsContent value="corndogs" className="mt-0">
              <div className="bg-black/60 backdrop-blur-sm border border-slate-900/50 p-6 rounded-md mb-8">
                <h2 className="text-2xl font-bold text-[#00e5d3] mb-4">KOREAN_CORNDOGS.sys</h2>

                {/* Actual Menu Image */}
                <div className="mb-8 flex justify-center">
                  <Card className="overflow-hidden border-slate-900/50 bg-black/60 backdrop-blur-sm w-full max-w-3xl">
                    <CardContent className="p-0">
                      <Image
                        src="/images/menu-corndogs.png"
                        alt="Korean Corndogs Menu"
                        width={800}
                        height={600}
                        className="w-full h-auto"
                      />
                    </CardContent>
                  </Card>
                </div>

                {/* Animated Corndog Showcase */}
                <div className="flex flex-wrap justify-center gap-8 mb-8">
                  <AnimatedCorndog name="HOT CHEETOS" coatingColor="#FF5722" coatingTexture="cheetos" size={120} />
                  <AnimatedCorndog name="RAMEN" coatingColor="#FFE0B2" coatingTexture="ramen" size={120} />
                  <AnimatedCorndog name="BLUE TAKIS" coatingColor="#2196F3" coatingTexture="takis" size={120} />
                </div>

                <p className="mb-4 text-white font-mono">
                  CHOOSE BETWEEN: ALL CHEESE (+$0.85), ALL SAUSAGE, OR HALF/HALF INSIDE
                </p>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  <div className="space-y-2">
                    <h3 className="font-bold text-white flex justify-between">
                      <span>HOT CHEETOS</span>
                      <span className="text-[#00e5d3]">$6.95</span>
                    </h3>
                  </div>
                  <div className="space-y-2">
                    <h3 className="font-bold text-white flex justify-between">
                      <span>RAMEN</span>
                      <span className="text-[#00e5d3]">$6.95</span>
                    </h3>
                  </div>
                  <div className="space-y-2">
                    <h3 className="font-bold text-white flex justify-between">
                      <span>SUGAR</span>
                      <span className="text-[#00e5d3]">$5.95</span>
                    </h3>
                  </div>
                  <div className="space-y-2">
                    <h3 className="font-bold text-white flex justify-between">
                      <span>BLUE TAKIS</span>
                      <span className="text-[#00e5d3]">$6.95</span>
                    </h3>
                  </div>
                  <div className="space-y-2">
                    <h3 className="font-bold text-white flex justify-between">
                      <span>ORIGINAL</span>
                      <span className="text-[#00e5d3]">$5.95</span>
                    </h3>
                  </div>
                  <div className="space-y-2">
                    <h3 className="font-bold text-white flex justify-between">
                      <span>POTATO</span>
                      <span className="text-[#00e5d3]">$6.95</span>
                    </h3>
                  </div>
                </div>
              </div>

              <div className="bg-black/60 backdrop-blur-sm border border-slate-900/50 p-6 rounded-md">
                <h2 className="text-2xl font-bold text-[#00e5d3] mb-4">ENTREES.sys</h2>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <h3 className="font-bold text-white">WINGS</h3>
                    <p className="text-sm text-muted-foreground font-mono">5PC $9.95 / 10PC $15.95</p>
                    <p className="text-sm text-muted-foreground font-mono">BBQ, KOREAN SESAME, LEMON PEPPER, BUFFALO</p>
                  </div>
                  <div className="space-y-2">
                    <h3 className="font-bold text-white">KOREAN RIBS</h3>
                    <p className="text-sm text-muted-foreground font-mono">
                      KOREAN RIBS, WHITE RICE, CUCUMBER SLICES $15.95
                    </p>
                  </div>
                  <div className="space-y-2">
                    <h3 className="font-bold text-white">SHRIMP WRAP</h3>
                    <p className="text-sm text-muted-foreground font-mono">
                      5PC WRAPPED SEASON SHRIMP SERVED WITH SWEET CHILI $9.95
                    </p>
                  </div>
                  <div className="space-y-2">
                    <h3 className="font-bold text-white">EGG ROLLS</h3>
                    <p className="text-sm text-muted-foreground font-mono">
                      $5.95, 5PC, CHOOSE FROM PORK, PORK N' SHRIMP, VEGGIE
                    </p>
                  </div>
                  <div className="space-y-2">
                    <h3 className="font-bold text-white">MASUBI</h3>
                    <p className="text-sm text-muted-foreground font-mono">
                      SPAM, RICE WRAPPED IN SEAWEED. 3PC $6.95/5PC $9.95
                    </p>
                  </div>
                  <div className="space-y-2">
                    <h3 className="font-bold text-white">BANH MI</h3>
                    <p className="text-sm text-muted-foreground font-mono">
                      VIETNAMESE SANDWICH - PORK, BEEF, CHICKEN, FRIED EGG, VEGGIE
                    </p>
                  </div>
                </div>
              </div>
            </TabsContent>

            {/* Bingsu Tab */}
            <TabsContent value="bingsu" className="mt-0">
              <div className="bg-black/60 backdrop-blur-sm border border-slate-900/50 p-6 rounded-md mb-8">
                <h2 className="text-2xl font-bold text-[#00e5d3] mb-4">BINGSU.sys</h2>

                {/* Actual Menu Image */}
                <div className="mb-8 flex justify-center">
                  <Card className="overflow-hidden border-slate-900/50 bg-black/60 backdrop-blur-sm w-full max-w-3xl">
                    <CardContent className="p-0">
                      <Image
                        src="/images/menu-bingsu.png"
                        alt="Bingsu Menu"
                        width={800}
                        height={600}
                        className="w-full h-auto"
                      />
                    </CardContent>
                  </Card>
                </div>

                <p className="mb-4 text-white font-mono">MILK-BASED KOREAN SHAVED ICE DESSERT</p>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  <div className="space-y-2">
                    <h3 className="font-bold text-white flex justify-between">
                      <span>CLASSIC MILK</span>
                      <span className="text-[#00e5d3]">$9.95</span>
                    </h3>
                    <p className="text-sm text-muted-foreground font-mono">CONDENSED MILK, RED BEAN, MOCHI, ALMOND</p>
                  </div>
                  <div className="space-y-2">
                    <h3 className="font-bold text-white flex justify-between">
                      <span>MANGO</span>
                      <span className="text-[#00e5d3]">$9.95</span>
                    </h3>
                    <p className="text-sm text-muted-foreground font-mono">
                      CONDENSED MILK, MANGO SYRUP, FRESH MANGO, WHIPPED CREAM
                    </p>
                  </div>
                  <div className="space-y-2">
                    <h3 className="font-bold text-white flex justify-between">
                      <span>STRAWBERRY</span>
                      <span className="text-[#00e5d3]">$9.95</span>
                    </h3>
                    <p className="text-sm text-muted-foreground font-mono">
                      CONDENSED MILK, STRAWBERRY SYRUP, FRESH STRAWBERRY, WHIPPED CREAM
                    </p>
                  </div>
                </div>
              </div>

              <div className="bg-black/60 backdrop-blur-sm border border-slate-900/50 p-6 rounded-md">
                <h2 className="text-2xl font-bold text-[#00e5d3] mb-4">PREMIUM_BINGSU.sys</h2>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="space-y-2">
                    <h3 className="font-bold text-white flex justify-between">
                      <span>STRAWBERRY MANGO</span>
                      <span className="text-[#00e5d3]">$11.99</span>
                    </h3>
                    <p className="text-sm text-muted-foreground font-mono">
                      CONDENSED MILK, STRAWBERRY N' MANGO SYRUP, FRESH FRUIT, WHIPPED CREAM
                    </p>
                  </div>
                  <div className="space-y-2">
                    <h3 className="font-bold text-white flex justify-between">
                      <span>STRAWBERRY CHEESE</span>
                      <span className="text-[#00e5d3]">$11.99</span>
                    </h3>
                    <p className="text-sm text-muted-foreground font-mono">
                      CONDENSED MILK, STRAWBERRY SYRUP, FRESH STRAWBERRY, WHIPPED CREAM, CHEESECAKE SLICE
                    </p>
                  </div>
                  <div className="space-y-2">
                    <h3 className="font-bold text-white flex justify-between">
                      <span>MANGO CHEESE</span>
                      <span className="text-[#00e5d3]">$11.99</span>
                    </h3>
                    <p className="text-sm text-muted-foreground font-mono">
                      CONDENSED MILK, MANGO SYRUP, FRESH MANGO, WHIPPED CREAM, CHEESECAKE SLICE
                    </p>
                  </div>
                </div>
              </div>
            </TabsContent>

            {/* Drinks Tab */}
            <TabsContent value="drinks" className="mt-0">
              <div className="bg-black/60 backdrop-blur-sm border border-slate-900/50 p-6 rounded-md mb-8">
                <h2 className="text-2xl font-bold text-[#00e5d3] mb-4">DRINKS.sys</h2>

                {/* Actual Menu Image */}
                <div className="mb-8 flex justify-center">
                  <Card className="overflow-hidden border-slate-900/50 bg-black/60 backdrop-blur-sm w-full max-w-3xl">
                    <CardContent className="p-0">
                      <Image
                        src="/images/menu-drinks.png"
                        alt="Drinks Menu"
                        width={800}
                        height={600}
                        className="w-full h-auto"
                      />
                    </CardContent>
                  </Card>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="bg-black/60 backdrop-blur-sm border border-slate-900/50 p-6 rounded-md">
                  <h2 className="text-2xl font-bold text-[#00e5d3] mb-4">SMOOTHIES.sys</h2>
                  <p className="mb-4 text-white font-mono">ALL SMOOTHIES $5.95 (MADE WITH REAL FRUIT)</p>

                  <ul className="space-y-2">
                    <li className="font-mono">STRAWBERRY</li>
                    <li className="font-mono">WATERMELON (SEASONAL)</li>
                    <li className="font-mono">MANGO</li>
                    <li className="font-mono">MANGONADA</li>
                    <li className="font-mono">AVOCADO (SEASONAL)</li>
                    <li className="font-mono">COOKIES N' CREAM</li>
                    <li className="font-mono">TARO</li>
                    <li className="font-mono">STRAWBERRY N' BANANA</li>
                  </ul>
                </div>

                <div className="bg-black/60 backdrop-blur-sm border border-slate-900/50 p-6 rounded-md">
                  <h2 className="text-2xl font-bold text-[#00e5d3] mb-4">MILK_TEAS.sys</h2>
                  <p className="mb-4 text-white font-mono">ALL MILK TEAS $5.95 (ADD BOBA FOR $0.85)</p>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <ul className="space-y-2">
                        <li className="font-mono">BROWN SUGAR</li>
                        <li className="font-mono">MILK TEA</li>
                        <li className="font-mono">PINK MILK</li>
                        <li className="font-mono">MATCHA</li>
                      </ul>
                    </div>
                    <div>
                      <ul className="space-y-2">
                        <li className="font-mono">HONEYDEW</li>
                        <li className="font-mono">TARO</li>
                        <li className="font-mono">THAI TEA</li>
                        <li className="font-mono">STRAWBERRY MILKTEA</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-900/30 py-8">
        <div className="container text-center">
          <Link href="/" className="inline-flex items-center gap-2 font-bold">
            <Image
              src="/images/ninja-logo.png"
              alt="Ninja Mochi Donut"
              width={30}
              height={30}
              className="rounded-full"
            />
            <span className="text-xl text-[#00e5d3]">NINJA</span>
            <span className="text-xl text-black dark:text-white">MOCHI</span>
          </Link>
          <p className="mt-4 font-mono text-sm text-[#00e5d3]/70">
            © {new Date().getFullYear()} NINJA MOCHI DONUT // ALL RIGHTS RESERVED
          </p>
        </div>
      </footer>
    </div>
  )
}
