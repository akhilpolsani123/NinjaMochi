"use client"

import { motion } from "framer-motion"
import Image from "next/image"
import Link from "next/link"
import { MapPin, Phone, Clock, ExternalLink } from "lucide-react"
import { ScanLines } from "@/components/scan-lines"
import { GlitchText } from "@/components/glitch-text"
import { NeonButton } from "@/components/neon-button"
import { Card, CardContent } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"

export default function LocationsPage() {
  return (
    <div className="dark min-h-screen bg-black text-slate-50">
      <ScanLines />

      {/* Navigation */}
      <header className="sticky top-0 z-50 border-b border-slate-900/30 bg-black/80 backdrop-blur-md">
        <div className="container flex h-16 items-center justify-between">
          <Link href="/" className="flex items-center gap-2 font-bold">
            <Image
              src="/images/ninja-logo.png"
              alt="Ninja Mochi Donut"
              width={40}
              height={40}
              className="rounded-full"
            />
            <span className="text-xl text-[#00e5d3]">NINJA</span>
            <span className="text-xl text-black dark:text-white">MOCHI</span>
          </Link>
          <nav className="hidden md:flex">
            <ul className="flex items-center gap-6">
              <li>
                <Link
                  href="/"
                  className="text-sm font-medium tracking-wide text-[#00e5d3] transition-colors hover:text-[#00e5d3]/80"
                >
                  _HOME
                </Link>
              </li>
              <li>
                <Link
                  href="/#about"
                  className="text-sm font-medium tracking-wide text-[#00e5d3] transition-colors hover:text-[#00e5d3]/80"
                >
                  _ABOUT
                </Link>
              </li>
              <li>
                <Link
                  href="/menu"
                  className="text-sm font-medium tracking-wide text-[#00e5d3] transition-colors hover:text-[#00e5d3]/80"
                >
                  _MENU
                </Link>
              </li>
              <li>
                <Link
                  href="/locations"
                  className="text-sm font-medium tracking-wide text-[#00e5d3] transition-colors hover:text-[#00e5d3]/80"
                >
                  _LOCATIONS
                </Link>
              </li>
            </ul>
          </nav>
          <Dialog>
            <DialogTrigger asChild>
              <NeonButton color="teal">ORDER NOW</NeonButton>
            </DialogTrigger>
            <DialogContent className="bg-slate-800 border-slate-700">
              <DialogHeader>
                <DialogTitle className="text-[#00e5d3] text-xl">Order by Phone</DialogTitle>
                <DialogDescription className="text-slate-300">
                  Call one of our locations to place your order
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 mt-4">
                <div className="p-4 border border-slate-700 rounded-md">
                  <h3 className="font-bold text-white mb-2">Saratoga Location</h3>
                  <p className="text-[#00e5d3] text-lg font-bold">(361) 442-2160</p>
                  <p className="text-sm text-slate-300 mt-1">6181 Saratoga Blvd Ste: 107A, Corpus Christi, TX 78414</p>
                </div>
                <div className="p-4 border border-slate-700 rounded-md">
                  <h3 className="font-bold text-white mb-2">Moore Plaza Location</h3>
                  <p className="text-[#00e5d3] text-lg font-bold">(361) 299-0458</p>
                  <p className="text-sm text-slate-300 mt-1">
                    5425 S Padre Island Dr Suite 113, Corpus Christi, TX 78411
                  </p>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative h-[40vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-black/50 backdrop-blur-sm z-0"></div>
        <motion.div
          className="relative z-10 text-center px-4"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <h1 className="text-5xl md:text-6xl font-bold tracking-tighter mb-4">
            <GlitchText>LOCATIONS.exe</GlitchText>
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto font-mono text-[#00e5d3]/70">
            {`>> FIND OUR NINJA MOCHI DONUT LOCATIONS IN CORPUS CHRISTI, TX`}
          </p>
        </motion.div>
      </section>

      {/* Locations Section */}
      <section className="py-12 px-4">
        <div className="container mx-auto max-w-6xl">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            {/* Location 1 */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2, duration: 0.5 }}
            >
              <Card className="border border-slate-900/50 bg-black/60 backdrop-blur-sm h-full">
                <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-[#00e5d3] to-transparent"></div>
                <CardContent className="p-6">
                  <div className="aspect-video w-full overflow-hidden mb-6 relative">
                    <div className="absolute inset-0 flex items-center justify-center bg-black/40">
                      <div className="text-center">
                        <h2 className="text-2xl font-bold text-[#00e5d3] mb-2">SARATOGA</h2>
                        <p className="text-sm font-mono text-white/70">LOCATION_1.sys</p>
                      </div>
                    </div>
                    <div className="absolute inset-0 opacity-30 mix-blend-color-dodge">
                      <ScanLines density={2} opacity={0.2} />
                    </div>
                  </div>

                  <div className="space-y-6">
                    <div className="flex items-start gap-3">
                      <MapPin className="mt-1 h-5 w-5 text-[#00e5d3]" />
                      <div>
                        <p className="font-mono font-medium text-[#00e5d3]">ADDRESS</p>
                        <p className="font-mono text-sm text-[#00e5d3]/70">
                          6181 Saratoga Blvd Ste: 107A
                          <br />
                          Corpus Christi, TX 78414
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <Phone className="mt-1 h-5 w-5 text-[#00e5d3]" />
                      <div>
                        <p className="font-mono font-medium text-[#00e5d3]">PHONE</p>
                        <p className="font-mono text-sm text-[#00e5d3]/70">(361) 442-2160</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <Clock className="mt-1 h-5 w-5 text-[#00e5d3]" />
                      <div>
                        <p className="font-mono font-medium text-[#00e5d3]">HOURS</p>
                        <div className="grid grid-cols-2 gap-x-4 font-mono text-sm text-[#00e5d3]/70">
                          <div>Monday</div>
                          <div>11AM–9PM</div>
                          <div>Tuesday</div>
                          <div>11AM–9PM</div>
                          <div>Wednesday</div>
                          <div>11AM–9PM</div>
                          <div>Thursday</div>
                          <div>11AM–9PM</div>
                          <div>Friday</div>
                          <div>11AM–9:30PM</div>
                          <div>Saturday</div>
                          <div>11AM–9:30PM</div>
                          <div>Sunday</div>
                          <div>11AM–9PM</div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="mt-8 flex flex-wrap gap-4">
                    <a
                      href="https://maps.app.goo.gl/6181SaratogaBlvdSte107ACorpusChristi"
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <NeonButton color="teal" className="gap-2">
                        <MapPin className="h-4 w-4" /> DIRECTIONS
                      </NeonButton>
                    </a>
                    <a href="tel:+13614422160">
                      <NeonButton color="teal" className="gap-2">
                        <Phone className="h-4 w-4" /> CALL
                      </NeonButton>
                    </a>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Location 2 */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4, duration: 0.5 }}
            >
              <Card className="border border-slate-900/50 bg-black/60 backdrop-blur-sm h-full">
                <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-[#00e5d3] to-transparent"></div>
                <CardContent className="p-6">
                  <div className="aspect-video w-full overflow-hidden mb-6 relative">
                    <div className="absolute inset-0 flex items-center justify-center bg-black/40">
                      <div className="text-center">
                        <h2 className="text-2xl font-bold text-[#00e5d3] mb-2">MOORE PLAZA</h2>
                        <p className="text-sm font-mono text-white/70">LOCATION_2.sys</p>
                      </div>
                    </div>
                    <div className="absolute inset-0 opacity-30 mix-blend-color-dodge">
                      <ScanLines density={2} opacity={0.2} />
                    </div>
                  </div>

                  <div className="space-y-6">
                    <div className="flex items-start gap-3">
                      <MapPin className="mt-1 h-5 w-5 text-[#00e5d3]" />
                      <div>
                        <p className="font-mono font-medium text-[#00e5d3]">ADDRESS</p>
                        <p className="font-mono text-sm text-[#00e5d3]/70">
                          5425 S Padre Island Dr Suite 113
                          <br />
                          Corpus Christi, TX 78411
                          <br />
                          Moore Plaza
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <Phone className="mt-1 h-5 w-5 text-[#00e5d3]" />
                      <div>
                        <p className="font-mono font-medium text-[#00e5d3]">PHONE</p>
                        <p className="font-mono text-sm text-[#00e5d3]/70">(361) 299-0458</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <Clock className="mt-1 h-5 w-5 text-[#00e5d3]" />
                      <div>
                        <p className="font-mono font-medium text-[#00e5d3]">HOURS</p>
                        <div className="grid grid-cols-2 gap-x-4 font-mono text-sm text-[#00e5d3]/70">
                          <div>Monday</div>
                          <div>11AM–9PM</div>
                          <div>Tuesday</div>
                          <div>11AM–9PM</div>
                          <div>Wednesday</div>
                          <div>11AM–9PM</div>
                          <div>Thursday</div>
                          <div>11AM–9PM</div>
                          <div>Friday</div>
                          <div>11AM–9:30PM</div>
                          <div>Saturday</div>
                          <div>11AM–9:30PM</div>
                          <div>Sunday</div>
                          <div>11AM–9PM</div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="mt-8 flex flex-wrap gap-4">
                    <a
                      href="https://maps.app.goo.gl/5425SPadreIslandDrSuite113CorpusChristi"
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <NeonButton color="teal" className="gap-2">
                        <MapPin className="h-4 w-4" /> DIRECTIONS
                      </NeonButton>
                    </a>
                    <a href="tel:+13612990458">
                      <NeonButton color="teal" className="gap-2">
                        <Phone className="h-4 w-4" /> CALL
                      </NeonButton>
                    </a>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>

          {/* Online Presence */}
          <motion.div
            className="mt-12"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6, duration: 0.5 }}
          >
            <Card className="border border-slate-900/50 bg-black/60 backdrop-blur-sm">
              <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-[#00e5d3] to-transparent"></div>
              <CardContent className="p-6">
                <h2 className="text-xl font-bold text-[#00e5d3] mb-6">ONLINE_PRESENCE.sys</h2>

                <div className="flex flex-col md:flex-row gap-8">
                  <div className="flex-1">
                    <div className="flex items-start gap-3 mb-4">
                      <ExternalLink className="mt-1 h-5 w-5 text-[#00e5d3]" />
                      <div>
                        <p className="font-mono font-medium text-[#00e5d3]">WEBSITE</p>
                        <p className="font-mono text-sm text-[#00e5d3]/70">
                          <a
                            href="https://ninjamochidonut.com"
                            target="_blank"
                            rel="noopener noreferrer"
                            className="hover:text-[#00e5d3]"
                          >
                            ninjamochidonut.com
                          </a>
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="flex-1">
                    <div className="flex items-start gap-3 mb-4">
                      <div className="mt-1 h-5 w-5 text-[#00e5d3] flex items-center justify-center">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="20"
                          height="20"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        >
                          <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path>
                        </svg>
                      </div>
                      <div>
                        <p className="font-mono font-medium text-[#00e5d3]">SOCIAL</p>
                        <p className="font-mono text-sm text-[#00e5d3]/70">
                          <a
                            href="https://facebook.com/ninjamochidonut"
                            target="_blank"
                            rel="noopener noreferrer"
                            className="hover:text-[#00e5d3]"
                          >
                            facebook.com/ninjamochidonut
                          </a>
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="mt-8">
                  <h3 className="text-lg font-medium text-[#00e5d3]">DELIVERY OPTIONS</h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
                    <div className="p-4 border border-[#00e5d3]/30 bg-[#00e5d3]/5 rounded-md">
                      <p className="font-mono font-medium text-[#00e5d3] mb-1">DINE-IN</p>
                      <p className="text-sm text-[#00e5d3]/70">Available at both locations</p>
                    </div>
                    <div className="p-4 border border-[#00e5d3]/30 bg-[#00e5d3]/5 rounded-md">
                      <p className="font-mono font-medium text-[#00e5d3] mb-1">TAKEOUT</p>
                      <p className="text-sm text-[#00e5d3]/70">Call ahead for faster service</p>
                    </div>
                    <div className="p-4 border border-[#00e5d3]/30 bg-[#00e5d3]/5 rounded-md">
                      <p className="font-mono font-medium text-[#00e5d3] mb-1">DELIVERY</p>
                      <p className="text-sm text-[#00e5d3]/70">Available through delivery apps</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-900/30 py-8">
        <div className="container text-center">
          <Link href="/" className="inline-flex items-center gap-2 font-bold">
            <Image
              src="/images/ninja-logo.png"
              alt="Ninja Mochi Donut"
              width={30}
              height={30}
              className="rounded-full"
            />
            <span className="text-xl text-[#00e5d3]">NINJA</span>
            <span className="text-xl text-black dark:text-white">MOCHI</span>
          </Link>
          <p className="mt-4 font-mono text-sm text-[#00e5d3]/70">
            © {new Date().getFullYear()} NINJA MOCHI DONUT // ALL RIGHTS RESERVED
          </p>
        </div>
      </footer>
    </div>
  )
}
