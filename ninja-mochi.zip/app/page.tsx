"use client"

import Image from "next/image"
import Link from "next/link"
import { ChevronRight, Clock, MapPin, Phone } from "lucide-react"
import { motion } from "framer-motion"

import { ScanLines } from "@/components/scan-lines"
import { GlitchText } from "@/components/glitch-text"
import { NeonButton } from "@/components/neon-button"
import { CyberpunkTitle } from "@/components/cyberpunk-title"
import { AnimatedFoodGallery } from "@/components/animated-food-gallery"
import { AnimatedBobaGallery } from "@/components/animated-boba-gallery"
import { AnimatedCorndogGallery } from "@/components/animated-corndog-gallery"
import { Card, CardContent } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"

export default function Home() {
  return (
    <div className="dark flex min-h-screen flex-col bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-slate-50">
      <ScanLines opacity={0.03} />

      {/* Navigation */}
      <header className="sticky top-0 z-50 border-b border-slate-700/30 bg-slate-900/80 backdrop-blur-md">
        <div className="container flex h-16 items-center justify-between">
          <Link href="/" className="flex items-center gap-2 font-bold">
            <Image
              src="/images/ninja-logo.png"
              alt="Ninja Mochi Donut"
              width={40}
              height={40}
              className="rounded-full"
            />
            <span className="text-xl text-[#00e5d3]">NINJA</span>
            <span className="text-xl text-white">MOCHI</span>
          </Link>
          <nav className="hidden md:flex">
            <ul className="flex items-center gap-6">
              <li>
                <Link
                  href="#"
                  className="text-sm font-medium tracking-wide text-[#00e5d3] transition-colors hover:text-[#00e5d3]/80"
                >
                  HOME
                </Link>
              </li>
              <li>
                <Link
                  href="#about"
                  className="text-sm font-medium tracking-wide text-[#00e5d3] transition-colors hover:text-[#00e5d3]/80"
                >
                  ABOUT
                </Link>
              </li>
              <li>
                <Link
                  href="/menu"
                  className="text-sm font-medium tracking-wide text-[#00e5d3] transition-colors hover:text-[#00e5d3]/80"
                >
                  MENU
                </Link>
              </li>
              <li>
                <Link
                  href="/locations"
                  className="text-sm font-medium tracking-wide text-[#00e5d3] transition-colors hover:text-[#00e5d3]/80"
                >
                  LOCATIONS
                </Link>
              </li>
            </ul>
          </nav>
          <Dialog>
            <DialogTrigger asChild>
              <NeonButton color="teal">ORDER NOW</NeonButton>
            </DialogTrigger>
            <DialogContent className="bg-slate-800 border-slate-700">
              <DialogHeader>
                <DialogTitle className="text-[#00e5d3] text-xl">Order by Phone</DialogTitle>
                <DialogDescription className="text-slate-300">
                  Call one of our locations to place your order
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 mt-4">
                <div className="p-4 border border-slate-700 rounded-md">
                  <h3 className="font-bold text-white mb-2">Saratoga Location</h3>
                  <p className="text-[#00e5d3] text-lg font-bold">(361) 442-2160</p>
                  <p className="text-sm text-slate-300 mt-1">6181 Saratoga Blvd Ste: 107A, Corpus Christi, TX 78414</p>
                </div>
                <div className="p-4 border border-slate-700 rounded-md">
                  <h3 className="font-bold text-white mb-2">Moore Plaza Location</h3>
                  <p className="text-[#00e5d3] text-lg font-bold">(361) 299-0458</p>
                  <p className="text-sm text-slate-300 mt-1">
                    5425 S Padre Island Dr Suite 113, Corpus Christi, TX 78411
                  </p>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative flex min-h-[70vh] flex-col items-center justify-center overflow-hidden bg-slate-900 text-white">
        <div className="absolute inset-0 z-0 opacity-80">
          <AnimatedFoodGallery />
        </div>
        <div className="container relative z-10 flex flex-col items-center justify-center gap-6 px-4 text-center sm:px-6">
          <div className="relative mb-4 flex flex-col items-center">
            <div className="absolute -top-8 left-0 right-0 text-xs font-medium text-[#00e5d3] opacity-70">
              DESSERT BAR
            </div>
            <CyberpunkTitle />
            <div className="mt-2 text-xs font-medium text-[#00e5d3] opacity-70">
              MOCHI DONUTS • BOBA • KOREAN CORNDOGS
            </div>
          </div>
          <p className="max-w-2xl text-lg font-medium text-[#00e5d3]/80">
            <GlitchText>ASIAN FUSION DESSERTS WITH A DIGITAL TWIST</GlitchText>
          </p>
          <div className="mt-6 flex flex-wrap gap-6">
            <Link href="/menu">
              <NeonButton color="teal" size="lg">
                VIEW MENU
              </NeonButton>
            </Link>
            <Dialog>
              <DialogTrigger asChild>
                <NeonButton color="teal" size="lg" variant="outline">
                  ORDER ONLINE
                </NeonButton>
              </DialogTrigger>
              <DialogContent className="bg-slate-800 border-slate-700">
                <DialogHeader>
                  <DialogTitle className="text-[#00e5d3] text-xl">Order by Phone</DialogTitle>
                  <DialogDescription className="text-slate-300">
                    Call one of our locations to place your order
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 mt-4">
                  <div className="p-4 border border-slate-700 rounded-md">
                    <h3 className="font-bold text-white mb-2">Saratoga Location</h3>
                    <p className="text-[#00e5d3] text-lg font-bold">(361) 442-2160</p>
                    <p className="text-sm text-slate-300 mt-1">
                      6181 Saratoga Blvd Ste: 107A, Corpus Christi, TX 78414
                    </p>
                  </div>
                  <div className="p-4 border border-slate-700 rounded-md">
                    <h3 className="font-bold text-white mb-2">Moore Plaza Location</h3>
                    <p className="text-[#00e5d3] text-lg font-bold">(361) 299-0458</p>
                    <p className="text-sm text-slate-300 mt-1">
                      5425 S Padre Island Dr Suite 113, Corpus Christi, TX 78411
                    </p>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>
        <div className="pointer-events-none absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-slate-900 to-transparent"></div>
      </section>

      {/* About Section */}
      <section id="about" className="py-16">
        <div className="container">
          <div className="mx-auto max-w-3xl text-center">
            <div className="inline-block border-b-2 border-[#00e5d3] pb-2">
              <h2 className="text-2xl font-bold tracking-wide text-[#00e5d3] sm:text-3xl">OUR STORY</h2>
            </div>
            <p className="mb-8 mt-6 text-[#00e5d3]/70">
              NINJA MOCHI DONUT COMBINES TRADITIONAL ASIAN DESSERTS WITH MODERN FUSION FLAVORS. OUR MENU FEATURES
              HANDCRAFTED MOCHI DONUTS, KOREAN CORNDOGS, BINGSU, BOBA DRINKS, AND MORE - ALL MADE WITH PREMIUM
              INGREDIENTS AND AUTHENTIC RECIPES.
            </p>
            <div className="grid gap-8 md:grid-cols-2">
              <Card className="border border-slate-700/50 bg-slate-800/60 backdrop-blur-sm">
                <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-[#00e5d3] to-transparent"></div>
                <CardContent className="flex flex-col items-center gap-2 p-6">
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-[#00e5d3]/20 text-[#00e5d3]">
                    <MapPin className="h-6 w-6" />
                  </div>
                  <h3 className="text-xl font-medium text-[#00e5d3]">SARATOGA LOCATION</h3>
                  <p className="text-center text-sm text-[#00e5d3]/70">
                    6181 Saratoga Blvd Ste: 107A
                    <br />
                    Corpus Christi, TX 78414
                    <br />
                    (361) 442-2160
                  </p>
                  <div className="mt-2 text-center text-xs text-[#00e5d3]/70">
                    MON-THU: 11AM-9PM
                    <br />
                    FRI-SAT: 11AM-9:30PM
                    <br />
                    SUN: 11AM-9PM
                  </div>
                </CardContent>
              </Card>
              <Card className="border border-slate-700/50 bg-slate-800/60 backdrop-blur-sm">
                <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-[#00e5d3] to-transparent"></div>
                <CardContent className="flex flex-col items-center gap-2 p-6">
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-[#00e5d3]/20 text-[#00e5d3]">
                    <MapPin className="h-6 w-6" />
                  </div>
                  <h3 className="text-xl font-medium text-[#00e5d3]">MOORE PLAZA LOCATION</h3>
                  <p className="text-center text-sm text-[#00e5d3]/70">
                    5425 S Padre Island Dr Suite 113
                    <br />
                    Corpus Christi, TX 78411
                    <br />
                    (361) 299-0458
                  </p>
                  <div className="mt-2 text-center text-xs text-[#00e5d3]/70">
                    MON-THU: 11AM-9PM
                    <br />
                    FRI-SAT: 11AM-9:30PM
                    <br />
                    SUN: 11AM-9PM
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Mochi Donut Gallery */}
      <section className="relative w-full py-12">
        <div className="absolute inset-0 bg-gradient-to-r from-[#00e5d3]/5 to-slate-700/5 opacity-30" />

        <div className="text-center mb-8">
          <h2 className="text-2xl font-bold text-[#00e5d3] mb-2">SIGNATURE FLAVORS</h2>
          <p className="text-sm text-[#00e5d3]/70">EXPLORE OUR DELICIOUS MOCHI DONUT FLAVORS</p>
        </div>

        <div className="flex flex-wrap justify-center gap-8 max-w-5xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1, duration: 0.5 }}
            className="text-center"
          >
            <div className="relative w-[150px] h-[150px] mb-2">
              <Image src="/images/donuts/strawberry.png" alt="Strawberry Mochi Donut" fill className="object-contain" />
            </div>
            <p className="text-sm font-medium text-[#00e5d3]">STRAWBERRY</p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2, duration: 0.5 }}
            className="text-center"
          >
            <div className="relative w-[150px] h-[150px] mb-2">
              <Image src="/images/donuts/chocolate.png" alt="Chocolate Mochi Donut" fill className="object-contain" />
            </div>
            <p className="text-sm font-medium text-[#00e5d3]">CHOCOLATE</p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3, duration: 0.5 }}
            className="text-center"
          >
            <div className="relative w-[150px] h-[150px] mb-2">
              <Image src="/images/donuts/matcha.png" alt="Matcha Mochi Donut" fill className="object-contain" />
            </div>
            <p className="text-sm font-medium text-[#00e5d3]">MATCHA</p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 0.5 }}
            className="text-center"
          >
            <div className="relative w-[150px] h-[150px] mb-2">
              <Image src="/images/donuts/taro.png" alt="Taro Mochi Donut" fill className="object-contain" />
            </div>
            <p className="text-sm font-medium text-[#00e5d3]">TARO</p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5, duration: 0.5 }}
            className="text-center"
          >
            <div className="relative w-[150px] h-[150px] mb-2">
              <Image
                src="/images/donuts/fruity-pebbles.png"
                alt="Fruity Pebbles Mochi Donut"
                fill
                className="object-contain"
              />
            </div>
            <p className="text-sm font-medium text-[#00e5d3]">FRUITY PEBBLES</p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6, duration: 0.5 }}
            className="text-center"
          >
            <div className="relative w-[150px] h-[150px] mb-2">
              <Image src="/images/donuts/oreo.png" alt="Oreo Mochi Donut" fill className="object-contain" />
            </div>
            <p className="text-sm font-medium text-[#00e5d3]">OREO</p>
          </motion.div>
        </div>
      </section>

      {/* Animated Boba Gallery */}
      <AnimatedBobaGallery />

      {/* Animated Corndog Gallery */}
      <AnimatedCorndogGallery />

      {/* Menu Preview Section */}
      <section id="menu" className="py-16">
        <div className="container">
          <div className="mx-auto max-w-3xl text-center">
            <div className="inline-block border-b-2 border-[#00e5d3] pb-2">
              <h2 className="text-2xl font-bold tracking-wide text-[#00e5d3] sm:text-3xl">MENU</h2>
            </div>
            <p className="mb-12 mt-6 text-[#00e5d3]/70">
              BROWSE OUR SELECTION OF ASIAN FUSION DESSERTS AND SNACKS, FEATURING AUTHENTIC FLAVORS WITH A MODERN TWIST.
            </p>
          </div>

          <div className="mt-12 text-center">
            <Link href="/menu">
              <NeonButton color="teal" size="lg">
                VIEW FULL MENU <ChevronRight className="ml-2 h-4 w-4" />
              </NeonButton>
            </Link>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-16">
        <div className="container">
          <div className="mx-auto max-w-3xl text-center">
            <div className="inline-block border-b-2 border-[#00e5d3] pb-2">
              <h2 className="text-2xl font-bold tracking-wide text-[#00e5d3] sm:text-3xl">CONTACT US</h2>
            </div>
            <p className="mb-12 mt-6 text-[#00e5d3]/70">
              VISIT OUR LOCATIONS OR REACH OUT ONLINE. OUR TEAM IS READY TO SERVE YOU.
            </p>
          </div>
          <div className="mx-auto max-w-4xl">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <Card className="border border-slate-700/50 bg-slate-800/60 backdrop-blur-sm">
                <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-[#00e5d3] to-transparent"></div>
                <CardContent className="p-6">
                  <h3 className="mb-4 text-xl font-bold text-[#00e5d3]">SARATOGA LOCATION</h3>
                  <div className="space-y-6">
                    <div className="flex items-start gap-3">
                      <MapPin className="mt-1 h-5 w-5 text-[#00e5d3]" />
                      <div>
                        <p className="font-medium text-[#00e5d3]">ADDRESS</p>
                        <p className="text-sm text-[#00e5d3]/70">
                          6181 Saratoga Blvd Ste: 107A
                          <br />
                          Corpus Christi, TX 78414
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <Phone className="mt-1 h-5 w-5 text-[#00e5d3]" />
                      <div>
                        <p className="font-medium text-[#00e5d3]">PHONE</p>
                        <p className="text-sm text-[#00e5d3]/70">(361) 442-2160</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <Clock className="mt-1 h-5 w-5 text-[#00e5d3]" />
                      <div>
                        <p className="font-medium text-[#00e5d3]">HOURS</p>
                        <p className="text-sm text-[#00e5d3]/70">
                          MONDAY - THURSDAY: 11AM-9PM
                          <br />
                          FRIDAY - SATURDAY: 11AM-9:30PM
                          <br />
                          SUNDAY: 11AM-9PM
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border border-slate-700/50 bg-slate-800/60 backdrop-blur-sm">
                <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-[#00e5d3] to-transparent"></div>
                <CardContent className="p-6">
                  <h3 className="mb-4 text-xl font-bold text-[#00e5d3]">PADRE ISLAND LOCATION</h3>
                  <div className="space-y-6">
                    <div className="flex items-start gap-3">
                      <MapPin className="mt-1 h-5 w-5 text-[#00e5d3]" />
                      <div>
                        <p className="font-medium text-[#00e5d3]">ADDRESS</p>
                        <p className="text-sm text-[#00e5d3]/70">
                          5425 S Padre Island Dr Suite 113
                          <br />
                          Corpus Christi, TX 78411
                          <br />
                          Moore Plaza
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <Phone className="mt-1 h-5 w-5 text-[#00e5d3]" />
                      <div>
                        <p className="font-medium text-[#00e5d3]">PHONE</p>
                        <p className="text-sm text-[#00e5d3]/70">(361) 299-0458</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <Clock className="mt-1 h-5 w-5 text-[#00e5d3]" />
                      <div>
                        <p className="font-medium text-[#00e5d3]">HOURS</p>
                        <p className="text-sm text-[#00e5d3]/70">
                          MONDAY - THURSDAY: 11AM-9PM
                          <br />
                          FRIDAY - SATURDAY: 11AM-9:30PM
                          <br />
                          SUNDAY: 11AM-9PM
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="mt-8">
              <Card className="border border-slate-700/50 bg-slate-800/60 backdrop-blur-sm">
                <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-[#00e5d3] to-transparent"></div>
                <CardContent className="p-6">
                  <h3 className="mb-4 text-xl font-bold text-[#00e5d3]">ONLINE PRESENCE</h3>
                  <div className="flex items-start gap-3">
                    <div className="mt-1 h-5 w-5 text-[#00e5d3] flex items-center justify-center">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="20"
                        height="20"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      >
                        <circle cx="12" cy="12" r="10"></circle>
                        <line x1="2" y1="12" x2="22" y2="12"></line>
                        <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path>
                      </svg>
                    </div>
                    <div>
                      <p className="font-medium text-[#00e5d3]">WEBSITE</p>
                      <p className="text-sm text-[#00e5d3]/70">
                        <a
                          href="https://ninjamochidonut.com"
                          target="_blank"
                          rel="noopener noreferrer"
                          className="hover:text-[#00e5d3]"
                        >
                          ninjamochidonut.com
                        </a>
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-700/30 py-12">
        <div className="container">
          <div className="grid gap-8 md:grid-cols-3">
            <div>
              <h3 className="mb-4 flex items-center gap-2 text-xl font-bold">
                <Image
                  src="/images/ninja-logo.png"
                  alt="Ninja Mochi Donut"
                  width={30}
                  height={30}
                  className="rounded-full"
                />
                <span className="text-[#00e5d3]">NINJA</span>
                <span className="text-white">MOCHI</span>
              </h3>
              <p className="text-sm text-[#00e5d3]/70">
                ASIAN FUSION DESSERT BAR. MOCHI DONUTS, BOBA, KOREAN CORNDOGS, AND MORE.
              </p>
              <p className="text-sm text-[#00e5d3]/70 mt-2">TWO LOCATIONS IN CORPUS CHRISTI, TX</p>
              <p className="text-sm text-[#00e5d3]/70 mt-2">
                <a
                  href="https://ninjamochidonut.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-[#00e5d3]"
                >
                  ninjamochidonut.com
                </a>
              </p>
            </div>
            <div>
              <h3 className="mb-4 text-lg font-medium text-[#00e5d3]">LINKS</h3>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="#" className="text-[#00e5d3]/80 transition-colors hover:text-[#00e5d3]">
                    HOME
                  </Link>
                </li>
                <li>
                  <Link href="#about" className="text-[#00e5d3]/80 transition-colors hover:text-[#00e5d3]">
                    ABOUT
                  </Link>
                </li>
                <li>
                  <Link href="/menu" className="text-[#00e5d3]/80 transition-colors hover:text-[#00e5d3]">
                    MENU
                  </Link>
                </li>
                <li>
                  <Link href="/locations" className="text-[#00e5d3]/80 transition-colors hover:text-[#00e5d3]">
                    LOCATIONS
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="mb-4 text-lg font-medium text-[#00e5d3]">FOLLOW US</h3>
              <p className="mb-4 text-sm text-[#00e5d3]/70">JOIN US FOR UPDATES AND EXCLUSIVE DEALS.</p>
              <div className="flex gap-4">
                <NeonButton color="teal">INSTAGRAM</NeonButton>
                <NeonButton color="teal">FACEBOOK</NeonButton>
              </div>
            </div>
          </div>
          <div className="mt-8 border-t border-slate-700/30 pt-8 text-center text-xs text-[#00e5d3]/50">
            <p>© {new Date().getFullYear()} NINJA MOCHI DONUT - ALL RIGHTS RESERVED</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
